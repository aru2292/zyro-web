# ZYRO website — GitHub Pages (upload the zip, nothing else)

## One-time setup (about 2 minutes)
1. Create a **public** repo, e.g. `zyro-site`.
2. Upload `zyro-site.zip` to the repo root (Add file → Upload files → drop the zip → Commit). **Do not extract it.**
3. Create the workflow file once: Add file → **Create new file** → name it exactly
   `.github/workflows/pages.yml` → paste the content of `pages.yml` (included in this zip under `.github/workflows/`) → Commit.
4. Repo → **Settings → Pages** → Build and deployment → Source: **GitHub Actions**.
5. Actions tab → wait for "Deploy ZYRO site" to go green. Site: `https://<username>.github.io/zyro-site/`.

## Every update after that
Upload the new `zyro-site.zip` to the repo root (replace the old one). The workflow unzips it and publishes automatically.

## Live stats
Set `STATS_URL` at the top of the script in `index.html` to your bot's `/stats` URL (see the bot README), then update the zip.

## Free custom domain (optional)
Settings → Pages → Custom domain, or a free subdomain service that accepts a GitHub pull request.
